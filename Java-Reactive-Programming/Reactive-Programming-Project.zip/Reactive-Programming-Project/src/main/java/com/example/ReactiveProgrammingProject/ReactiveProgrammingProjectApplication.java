package com.example.ReactiveProgrammingProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReactiveProgrammingProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReactiveProgrammingProjectApplication.class, args);
	}

}
