package com.example.DebuggApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DebuggAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
